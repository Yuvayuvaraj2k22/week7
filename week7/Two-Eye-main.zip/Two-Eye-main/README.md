# Eye Movement Exercise

In this project,eye balls follow the mouse position on the screen using the mouse events.

## Steps to Run the Project

Step 1: Add a second "eye" to the element.

Step 2: Move the cursor on the screen to make the move of eye balls.

## Future improvement 

 Planned to distinguish more clearly between natural blinking of eyes and explicit blinking.

Compatibility with Windows.
